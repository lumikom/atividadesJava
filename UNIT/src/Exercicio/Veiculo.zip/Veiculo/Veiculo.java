package Veiculo;

public interface Veiculo {
    public String ligarMotor();

    public String acelerar();

    public String freiar();

    public String buzinar();

}
